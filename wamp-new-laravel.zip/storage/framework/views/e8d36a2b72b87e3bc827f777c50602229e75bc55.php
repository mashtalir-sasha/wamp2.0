<div <?php echo $attributes; ?>><?php echo $value; ?> <?php echo $append; ?>

<?php if($small): ?>
<small class="clearfix"><?php echo $small; ?></small>
<?php endif; ?>
</div>
