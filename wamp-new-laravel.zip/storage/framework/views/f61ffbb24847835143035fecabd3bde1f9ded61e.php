<nav class="nav">
	<div class="container">
		<div class="row justify-content-between align-items-center">
			<div class="nav-btn d-lg-none">
				<button class="nav-toggle">
					<span class="bar-top"></span>
					<span class="bar-mid"></span>
					<span class="bar-bot"></span>
				</button>
			</div>  
			<a href="<?php echo e(route('home')); ?>" class="nav-logo">
				<span class="nav-logo__note">web | advertising | marketing</span>
				<img src="/img/logo.svg" alt="logo" class="nav-logo__img">
			</a>
			<div class="col-lg-5 d-none d-lg-block">
				<ul class="nav-list">
					<li class="nav-list__item <?php if(Route::currentRouteName() == 'home'): ?> active <?php endif; ?>">
						<a href="<?php echo e(route('home')); ?>"><?php echo e(trans('main.nav1')); ?></a>
					</li>
					<li class="nav-list__item nav-list__item_nohover">
						<a href="#" class="services-link"><?php echo e(trans('main.nav2')); ?> <i>></i></a>
						<ul class="dropdown-list">
						<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li class="dropdown-list__item">
								<a href="<?php echo e(route('service', $item->page->slug)); ?>"><?php echo e(mb_strimwidth( Helpers::getLangString($item,'title'), 0, 39, "..." )); ?></a>
							</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</li>
					<li class="nav-list__item">
						<a <?php if(Route::currentRouteName() == 'home'): ?> href="#cases" class="anchor" <?php else: ?> href="<?php echo e(route('home')); ?>#cases" <?php endif; ?>><?php echo e(trans('main.nav3')); ?></a>
					</li>
					<li class="nav-list__item <?php if(Route::currentRouteName() == 'portfolio'): ?> active <?php endif; ?>">
						<a href="<?php echo e(route('portfolio')); ?>"><?php echo e(trans('main.nav4')); ?></a>
					</li>
					<li class="nav-list__item">
						<a <?php if(Route::currentRouteName() == 'home'): ?> href="#about" class="anchor" <?php else: ?> href="<?php echo e(route('home')); ?>#about" <?php endif; ?>><?php echo e(trans('main.nav5')); ?></a>
					</li>
				</ul>
			</div>
			<div class="col-lg-5 align-items-center justify-content-end flex-wrap d-none d-lg-flex">
				<ul class="nav-list">
					<li class="nav-list__item">
						<a href="https://blog.wamp.com.ua" target="_blank"><?php echo e(trans('main.nav6')); ?></a>
					</li>
					<li class="nav-list__item">
						<a <?php if(Route::currentRouteName() == 'home'): ?> href="#contacts" class="anchor" <?php else: ?> href="<?php echo e(route('home')); ?>#contacts" <?php endif; ?>><?php echo e(trans('main.nav7')); ?></a>
					</li>
				</ul>
				<a href="tel:+38<?php echo e(preg_replace('~[^0-9]~','',$contacts['phone'])); ?>" class="nav__phone"><?php echo e($contacts->phone); ?></a>
				<div class="nav-btns">
					<div class="nav-lang">
						<a <?php if(localization()->getCurrentLocale() == 'ru'): ?> class="nav-lang__item active" <?php else: ?> href="<?php echo e(localization()->getLocalizedURL('ru')); ?>" class="nav-lang__item" <?php endif; ?>>ru</a>
						<a <?php if(localization()->getCurrentLocale() == 'en'): ?> class="nav-lang__item active" <?php else: ?> href="<?php echo e(localization()->getLocalizedURL('en')); ?>" class="nav-lang__item" <?php endif; ?>>en</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</nav>

<nav class="nav-mob d-flex d-lg-none">
	<div class="nav-mob__content">
		<ul class="nav-list">
			<li class="nav-list__item">
				<a href="<?php echo e(route('home')); ?>" class="anchor"><?php echo e(trans('main.nav1')); ?></a>
			</li>
			<li class="nav-list__item nav-list__item_nohover">
				<a href="#" class="services-link"><?php echo e(trans('main.nav2')); ?> <i>></i></a>
				<ul class="dropdown-list">
				<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li class="dropdown-list__item">
						<a href="<?php echo e(route('service', $item->page->slug)); ?>"><?php echo e(mb_strimwidth( Helpers::getLangString($item,'title'), 0, 39, "..." )); ?></a>
					</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</li>
			<li class="nav-list__item">
				<a <?php if(Route::currentRouteName() == 'home'): ?> href="#cases" class="anchor" <?php else: ?> href="<?php echo e(route('home')); ?>#cases" <?php endif; ?>><?php echo e(trans('main.nav3')); ?></a>
			</li>
			<li class="nav-list__item">
				<a href="<?php echo e(route('portfolio')); ?>"><?php echo e(trans('main.nav4')); ?></a>
			</li>
			<li class="nav-list__item">
				<a <?php if(Route::currentRouteName() == 'home'): ?> href="#about" class="anchor" <?php else: ?> href="<?php echo e(route('home')); ?>#about" <?php endif; ?>><?php echo e(trans('main.nav5')); ?></a>
			</li>
			<li class="nav-list__item">
				<a href="https://blog.wamp.com.ua" target="_blank"><?php echo e(trans('main.nav6')); ?></a>
			</li>
			<li class="nav-list__item">
				<a <?php if(Route::currentRouteName() == 'home'): ?> href="#contacts" class="anchor" <?php else: ?> href="<?php echo e(route('home')); ?>#contacts" <?php endif; ?>><?php echo e(trans('main.nav7')); ?></a>
			</li>
		</ul>
		<a href="tel:+38<?php echo e(preg_replace('~[^0-9]~','',$contacts['phone'])); ?>" class="nav__phone"><?php echo e($contacts->phone); ?></a>
		<div class="nav-btns">
			<a href="#" class="nav__callback"><?php echo e(trans('main.callback')); ?></a>
			<div class="nav-lang">
				<a <?php if(localization()->getCurrentLocale() == 'ru'): ?> class="nav-lang__item active" <?php else: ?> href="<?php echo e(localization()->getLocalizedURL('ru')); ?>" class="nav-lang__item" <?php endif; ?>>ru</a>
				<a <?php if(localization()->getCurrentLocale() == 'en'): ?> class="nav-lang__item active" <?php else: ?> href="<?php echo e(localization()->getLocalizedURL('en')); ?>" class="nav-lang__item" <?php endif; ?>>en</a>
			</div>
		</div>
	</div>
</nav>