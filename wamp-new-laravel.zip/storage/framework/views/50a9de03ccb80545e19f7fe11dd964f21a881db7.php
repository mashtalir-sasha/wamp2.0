<?php
$title = Helpers::getLangString($service, 'meta_title');
$description = Helpers::getLangString($service, 'meta_description');
$keywords = Helpers::getLangString($service, 'meta_keywords');
$partTitle = trans('main.part_title');
?>

<?php $__env->startSection('title', "$title $partTitle"); ?>
<?php $__env->startSection('description', "$description"); ?>
<?php $__env->startSection('keywords', "$keywords"); ?>

<?php $__env->startSection('opengraph'); ?>
<meta property="og:title" content="<?php echo e($title); ?><?php echo e($partTitle); ?>">
	<meta property="og:description" content="<?php echo e($description); ?>">
	<meta property="og:type" content="website">
	<meta property="og:url" content="<?php echo e(Request::url()); ?>">
	<meta property="og:image" content="<?php echo e(asset($service->image)); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('templates.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<header class="head height" style="background-image: url(/<?php echo e($service->image); ?>)">
	<div class="container">
		<div class="row align-items-center justify-content-end">
			<div class="col-xl-8 col-md-9">
				<div class="block-title">
					<h1 class="block-title__ttl"><?php echo Helpers::getLangString($service,'title'); ?></h1>
					<h2 class="block-title__txt"><?php echo Helpers::getLangString($service,'text'); ?></h2>
				</div>
				<a href="#modal4" class="head__btn btn fancybox"><?php echo e(trans('main.main_btn')); ?></a>
			</div>
		</div>
	</div>
</header>

<?php $__currentLoopData = $service->info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section id="service<?php echo e($item->id); ?>" class="service-content">
	<div class="container service-content__wrap">
	<?php if($loop->iteration == 1): ?>
		<div class="animate-container animate-container_i1">
			<img src="/img/animation/1.png" alt="animate" class="animate">
		</div>
		<div class="animate-container animate-container_i2">
			<img src="/img/animation/2.png" alt="animate" class="animate">
		</div>
		<div class="animate-container animate-container_i3">
			<img src="/img/animation/3.png" alt="animate" class="animate">
		</div>
	<?php elseif($loop->iteration == 2): ?>
		<div class="animate-container animate-container_i2">
			<img src="/img/animation/2.png" alt="animate" class="animate">
		</div>
		<div class="animate-container animate-container_i4">
			<img src="/img/animation/4.png" alt="animate" class="animate">
		</div>
	<?php elseif($loop->iteration == 3): ?>
		<div class="animate-container animate-container_i5">
			<img src="/img/animation/5.png" alt="animate" class="animate">
		</div>
		<div class="animate-container animate-container_i7">
			<img src="/img/animation/7.png" alt="animate" class="animate">
		</div>
		<div class="animate-container animate-container_i8">
			<img src="/img/animation/8.png" alt="animate" class="animate">
		</div>
	<?php endif; ?>
		<div class="row align-items-center">
			<div class="col-lg-6 ml60">
				<h3 class="service-content__ttl"><?php echo Helpers::getLangString($item,'page_title'); ?></h3>
				<div class="service-content__screen d-block d-lg-none">
					<div class="service-content__img" style="background-image: url(/<?php echo e($item->page_img); ?>);"></div>
				</div>
				<div class="service-content__txt">
					<?php echo Helpers::getLangString($item,'page_text'); ?>

				</div>
				<div class="service-content__line"></div>
				<p class="service-content__note"><?php echo Helpers::getLangString($item,'page_note'); ?></p>
				<!-- <p class="service-content__price">Стоимость <?php echo e($item->price); ?></p> -->
				<a href="#modal3" class="service-content__btn btn fancybox"><?php echo e(trans('main.serivePage_btn')); ?></a>
			</div>
			<div class="col-lg-5 d-none d-lg-block">
				<div class="service-content__screen">
					<div class="service-content__img" style="background-image: url(/<?php echo e($item->page_img); ?>);"></div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $service->portfolio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section class="service-portfolio">
	<div class="container">
		<?php if($loop->iteration == 1): ?>
		<div class="animate-container animate-container_i9">
			<img src="/img/animation/9.png" alt="animate" class="animate">
		</div>
		<div class="animate-container animate-container_i10">
			<img src="/img/animation/10.png" alt="animate" class="animate">
		</div>
		<?php elseif($loop->iteration == 2): ?>
		<div class="animate-container animate-container_i11">
			<img src="/img/animation/11.png" alt="animate" class="animate">
		</div>
		<?php elseif($loop->iteration == 3): ?>
		<div class="animate-container animate-container_i12">
			<img src="/img/animation/12.png" alt="animate" class="animate">
		</div>
		<div class="animate-container animate-container_i12">
			<img src="/img/animation/12.png" alt="animate" class="animate">
		</div>
		<?php endif; ?>
		<div class="row">
			<div class="col">
				<h3 class="service-portfolio__ttl"><?php echo Helpers::getLangString($item,'title'); ?></h3>
			</div>
		</div>
		<div class="row">
			<?php $__currentLoopData = $item->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-6">
				<?php if($loop->iteration > 4): ?>
				<picture>
					<source srcset="/<?php echo e(pathinfo($image, PATHINFO_DIRNAME)); ?>/@1x/<?php echo e(pathinfo($image, PATHINFO_FILENAME)); ?>.webp 1x, /<?php echo e(pathinfo($image, PATHINFO_DIRNAME)); ?>/<?php echo e(pathinfo($image, PATHINFO_FILENAME)); ?>.webp 2x" type="image/webp">
					<img srcset="/<?php echo e(pathinfo($image, PATHINFO_DIRNAME)); ?>/@1x/<?php echo e(pathinfo($image, PATHINFO_FILENAME)); ?>.<?php echo e(pathinfo($image, PATHINFO_EXTENSION)); ?> 1x, /<?php echo e($image); ?> 2x" alt="portfolio" class="service-portfolio__img none" loading="lazy">
				</picture>
				<?php else: ?>
				<picture>
					<source srcset="/<?php echo e(pathinfo($image, PATHINFO_DIRNAME)); ?>/@1x/<?php echo e(pathinfo($image, PATHINFO_FILENAME)); ?>.webp 1x, /<?php echo e(pathinfo($image, PATHINFO_DIRNAME)); ?>/<?php echo e(pathinfo($image, PATHINFO_FILENAME)); ?>.webp 2x" type="image/webp">
					<img srcset="/<?php echo e(pathinfo($image, PATHINFO_DIRNAME)); ?>/@1x/<?php echo e(pathinfo($image, PATHINFO_FILENAME)); ?>.<?php echo e(pathinfo($image, PATHINFO_EXTENSION)); ?> 1x, /<?php echo e($image); ?> 2x" alt="portfolio" class="service-portfolio__img" loading="lazy">
				</picture>
				<?php endif; ?>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<div class="row">
			<div class="col">
				<?php if( count($item->images) > 4 ): ?>
				<a href="#" class="service-portfolio__btn btn openMore"><?php echo e(trans('main.more_example')); ?></a>
				<a href="#modal4" class="service-portfolio__btn btn openModal none fancybox"><?php echo e(trans('main.main_btn')); ?></a>
				<?php else: ?>
				<a href="#modal4" class="service-portfolio__btn btn fancybox"><?php echo e(trans('main.main_btn')); ?></a>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<section class="service-form">
	<div class="service-form__wrap">
		<form class="container form_check">
			<input type="hidden" name="title" value="<?php echo e(trans('main.servicePage_formTtl')); ?>">
			<div class="row align-items-end justify-content-center justify-content-lg-start">
				<div class="col-lg-3 offset-lg-1 col-md-4 col-sm-6">
					<h3 class="service-form__ttl"><?php echo trans('main.servicePage_form'); ?></h3>
					<div class="rline">
						<input type="text" name="business" class="service-form__input rfield" placeholder="<?php echo e(trans('main.business2')); ?>">
					</div>
				</div>
				<div class="col-lg-3 col-md-4 col-sm-6">
					<h3 class="service-form__ttl"><?php echo trans('main.servicePage_form_item1'); ?></h3>
					<div class="rline">
						<input type="text" name="phone" class="service-form__input rfield" placeholder="<?php echo e(trans('main.phone')); ?>">
					</div>
				</div>
				<div class="col-lg-2 col-md-4 col-sm-6">
					<h3 class="service-form__ttl service-form__ttl_last"><span><?php echo trans('main.servicePage_form_item2'); ?></span></h3>
					<button class="service-form__btn btnsubmit btn"><?php echo e(trans('main.submit')); ?></button>
				</div>
				<img src="/img/service-form__img.png" alt="form" class="service-form__img d-none d-lg-block">
			</div>
		</form>
	</div>
</section>

<?php echo $__env->make('templates.about', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.clients', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.map', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>