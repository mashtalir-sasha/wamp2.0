<?php $__env->startSection('title', trans('main.title_portf')); ?>
<?php $__env->startSection('description', trans('main.description')); ?>
<?php $__env->startSection('keywords', ''); ?>

<?php $__env->startSection('opengraph'); ?>
<meta property="og:title" content="<?php echo e(trans('main.title_portf')); ?>">
	<meta property="og:description" content="<?php echo e(trans('main.description')); ?>">
	<meta property="og:type" content="website">
	<meta property="og:url" content="<?php echo e(Request::url()); ?>">
	<meta property="og:image" content="<?php echo e(asset('img/portfolio-bg.jpg')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('templates.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<header class="head height" style="background-image: url(img/portfolio-bg.jpg)">
	<div class="container">
		<div class="row align-items-center justify-content-end">
			<div class="col-xl-8 col-md-9">
				<div class="block-title">
					<h1 class="block-title__ttl"><?php echo trans('main.portf_h1'); ?></h1>
					<h2 class="block-title__txt"><?php echo trans('main.portf_h2'); ?></h2>
				</div>
				<a href="#modal4" class="head__btn btn fancybox"><?php echo e(trans('main.main_btn')); ?></a>
			</div>
		</div>
	</div>
</header>

<?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section class="service-portfolio <?php if($loop->iteration == 1): ?> service-portfolio_pt <?php endif; ?>">
	<div class="container">
		<?php if($loop->iteration == 1): ?>
		<div class="animate-container animate-container_i9">
			<img src="/img/animation/9.png" alt="animate" class="animate">
		</div>
		<div class="animate-container animate-container_i10">
			<img src="/img/animation/10.png" alt="animate" class="animate">
		</div>
		<?php elseif($loop->iteration == 2): ?>
		<div class="animate-container animate-container_i11">
			<img src="/img/animation/11.png" alt="animate" class="animate">
		</div>
		<?php elseif($loop->iteration == 3): ?>
		<div class="animate-container animate-container_i12">
			<img src="/img/animation/12.png" alt="animate" class="animate">
		</div>
		<div class="animate-container animate-container_i12">
			<img src="/img/animation/12.png" alt="animate" class="animate">
		</div>
		<?php endif; ?>
		<div class="row">
			<div class="col">
				<h3 class="service-portfolio__ttl"><?php echo Helpers::getLangString($item,'title'); ?></h3>
			</div>
		</div>
		<div class="row">
			<?php $__currentLoopData = $item->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-6">
				<?php if($loop->iteration > 4): ?>
				<picture>
					<source srcset="/<?php echo e(pathinfo($image, PATHINFO_DIRNAME)); ?>/@1x/<?php echo e(pathinfo($image, PATHINFO_FILENAME)); ?>.webp 1x, /<?php echo e(pathinfo($image, PATHINFO_DIRNAME)); ?>/<?php echo e(pathinfo($image, PATHINFO_FILENAME)); ?>.webp 2x" type="image/webp">
					<img srcset="/<?php echo e(pathinfo($image, PATHINFO_DIRNAME)); ?>/@1x/<?php echo e(pathinfo($image, PATHINFO_FILENAME)); ?>.<?php echo e(pathinfo($image, PATHINFO_EXTENSION)); ?> 1x, /<?php echo e($image); ?> 2x" alt="portfolio" class="service-portfolio__img none" loading="lazy">
				</picture>
				<?php else: ?>
				<picture>
					<source srcset="/<?php echo e(pathinfo($image, PATHINFO_DIRNAME)); ?>/@1x/<?php echo e(pathinfo($image, PATHINFO_FILENAME)); ?>.webp 1x, /<?php echo e(pathinfo($image, PATHINFO_DIRNAME)); ?>/<?php echo e(pathinfo($image, PATHINFO_FILENAME)); ?>.webp 2x" type="image/webp">
					<img srcset="/<?php echo e(pathinfo($image, PATHINFO_DIRNAME)); ?>/@1x/<?php echo e(pathinfo($image, PATHINFO_FILENAME)); ?>.<?php echo e(pathinfo($image, PATHINFO_EXTENSION)); ?> 1x, /<?php echo e($image); ?> 2x" alt="portfolio" class="service-portfolio__img" loading="lazy">
				</picture>
				<?php endif; ?>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<div class="row">
			<div class="col">
				<?php if( count($item->images) > 4 ): ?>
				<a href="#" class="service-portfolio__btn btn openMore"><?php echo e(trans('main.more_example')); ?></a>
				<a href="#modal4" class="service-portfolio__btn btn openModal none fancybox"><?php echo e(trans('main.main_btn')); ?></a>
				<?php else: ?>
				<a href="#modal4" class="service-portfolio__btn btn fancybox"><?php echo e(trans('main.main_btn')); ?></a>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $__env->make('templates.example-form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.about', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.clients', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.map', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>