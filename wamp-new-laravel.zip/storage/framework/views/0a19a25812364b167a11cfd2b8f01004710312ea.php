<?php $__env->startSection('title', trans('main.title')); ?>
<?php $__env->startSection('description', trans('main.description')); ?>
<?php $__env->startSection('keywords', ''); ?>

<?php $__env->startSection('opengraph'); ?>
<meta property="og:title" content="<?php echo e(trans('main.title')); ?>">
	<meta property="og:description" content="<?php echo e(trans('main.description')); ?>">
	<meta property="og:type" content="website">
	<meta property="og:url" content="<?php echo e(Request::url()); ?>">
	<meta property="og:image" content="<?php echo e(asset('img/main-bg.jpg')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('templates.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<header class="head height" style="background-image: url(/img/main-bg.jpg)">
	<div class="container">
		<div class="row align-items-center justify-content-end">
			<div class="col-xl-8 col-md-9">
				<div class="block-title">
					<h1 class="block-title__ttl"><?php echo trans('main.main_h1'); ?></h1>
					<h2 class="block-title__txt"><?php echo trans('main.main_h2'); ?></h2>
				</div>
				<a href="#modal1" class="head__btn btn fancybox"><?php echo e(trans('main.main_btn')); ?></a>
			</div>
		</div>
	</div>
</header>

<section id="services" class="services">
	<div class="container">
		<div class="animate-container animate-container_i5">
			<img src="/img/animation/5.png" alt="animate" class="animate">
		</div>
		<div class="animate-container animate-container_i7">
			<img src="/img/animation/7.png" alt="animate" class="animate">
		</div>
		<div class="animate-container animate-container_i8">
			<img src="/img/animation/8.png" alt="animate" class="animate">
		</div>
		<div class="row">
			<div class="col">
				<h3 class="services__ttl"><?php echo trans('main.service_ttl'); ?></h3>
				<p class="services__txt"><?php echo trans('main.service_txt'); ?></p>
			</div>
		</div>
		<div class="row services-wrap">
		<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-lg-4 col-md-6">
				<div class="service">
					<?php if($item->is_anchor == 1): ?>
					<a href="<?php echo e(route('service', $item->page->slug)); ?>#service<?php echo e($item->id); ?>" class="service-ttl">
						<img src="<?php echo e($item->ico); ?>" alt="ico" class="service-ttl__ico">
						<h4 class="service-ttl__txt"><?php echo e(Helpers::getLangString($item,'title')); ?></h4>
					</a>
					<?php else: ?>
					<a href="<?php echo e(route('service', $item->page->slug)); ?>" class="service-ttl">
						<img src="<?php echo e($item->ico); ?>" alt="ico" class="service-ttl__ico">
						<h4 class="service-ttl__txt"><?php echo e(Helpers::getLangString($item,'title')); ?></h4>
					</a>
					<?php endif; ?>
					<p class="service-txt"><?php echo Helpers::getLangString($item,'text'); ?></p>
					<?php if($item->is_anchor == 1): ?>
					<a href="<?php echo e(route('service', $item->page->slug)); ?>#service<?php echo e($item->id); ?>" class="service-link"><?php echo e(trans('main.more_btn')); ?></a>
					<?php else: ?>
					<a href="<?php echo e(route('service', $item->page->slug)); ?>" class="service-link"><?php echo e(trans('main.more_btn')); ?></a>
					<?php endif; ?>
					<!-- <p class="service-price">Цена от <?php echo e($item->price); ?></p> -->
					<a href="#modal2" class="service-btn btn fancybox"><?php echo e(trans('main.service_btn')); ?></a>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</section>

<section class="fixbg fixbg_bg1">
	<div class="container">
		<div class="row">
			<div class="col">
				<h3 class="fixbg__ttl"><?php echo trans('main.fix_ttl'); ?></h3>
				<p class="fixbg__subttl"><?php echo trans('main.fix_txt'); ?></p>
			</div>
		</div>
	</div>
	<a href="#analysis" class="anchor scroll-downer">
		<span class="out-downder">
			<span class="in-downer">
				<span class="object-downer"></span>
			</span>
		</span>
	</a>
</section>

<section id="analysis" class="analysis">
	<div class="container">
		<div class="animate-container animate-container_i1">
			<img src="/img/animation/1.png" alt="animate" class="animate">
		</div>
		<div class="animate-container animate-container_i3">
			<img src="/img/animation/3.png" alt="animate" class="animate">
		</div>
		<div class="row">
			<div class="col">
				<h3 class="analysis__ttl"><?php echo e(trans('main.analysis_ttl')); ?></h3>
				<form class="analysis-form form_check">
					<input type="hidden" name="title" value="<?php echo e(trans('main.analysis_formTtl')); ?>">
					<h4 class="analysis-form__ttl"><?php echo trans('main.analysis_form'); ?></h4>
					<div class="analysis-form__wrap">
						<div class="row align-items-center">
							<div class="col-lg-7">
								<div class="rline">
									<input type="text" name="phone" class="analysis-form__input rfield" placeholder="<?php echo e(trans('main.phone_tg')); ?>">
								</div>
							</div>
							<div class="col-lg-5">
								<button class="btnsubmit btn analysis-form__btn"><?php echo e(trans('main.analysis_formBtn')); ?></button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</section>

<section id="cases" class="portfolio">
	<div class="container">
		<div class="animate-container animate-container_i12">
			<img src="/img/animation/12.png" alt="animate" class="animate">
		</div>
		<div class="animate-container animate-container_i13">
			<img src="/img/animation/12.png" alt="animate" class="animate">
		</div>
		<div class="row">
			<div class="col">
				<h3 class="portfolio__ttl"><?php echo trans('main.cases_ttl'); ?></h3>
			</div>
		</div>
		<div class="portfolio-slider">
		<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="portfolio-slider__slide">
				<div class="row">
					<div class="col-lg-6">
						<p class="project__type"><?php echo e(Helpers::getLangString($item,'type')); ?></p>
						<h4 class="project__name"><?php echo Helpers::getLangString($item,'title'); ?></h4>
						<?php if( isset( $item->sub_title ) ): ?>
						<p class="project-text__txt"><?php echo Helpers::getLangString($item,'sub_title'); ?></p>
						<?php endif; ?>
						<?php
							$link = parse_url($item->link);
							$path = isset($link['path']) && $link['path'] != '/' ? $link['path'] : '';
						?>
						<?php if( isset($item->link) ): ?>
						<!-- <a href="<?php echo e($item->link); ?>" rel="nofollow" target="_blank" class="project__link d-table d-sm-none"><?php echo e($link['host'] .$path); ?></a> -->
						<?php endif; ?>
						<div class="project-screen d-block d-sm-none">
							<img src="/img/ipad.png" alt="screen" class="project-screen__bg">
							<img src="/<?php echo e($item->image); ?>" alt="screnn" class="project-screen__img" loading="lazy">
						</div>
						<?php if( isset( $item->task ) ): ?>
						<h5 class="project-text__ttl"><?php echo e(trans('main.task')); ?></h5>
						<p class="project-text__txt"><?php echo Helpers::getLangString($item,'task'); ?></p>
						<?php endif; ?>
						<?php if( isset( $item->solution ) ): ?>
						<h5 class="project-text__ttl"><?php echo e(trans('main.solution')); ?></h5>
						<p class="project-text__txt"><?php echo Helpers::getLangString($item,'solution'); ?></p>
						<?php endif; ?>
						<?php if( isset( $item->strategy1 ) ): ?>
						<h5 class="project-text__ttl"><?php echo e(trans('main.strategy')); ?></h5>
						<ul class="project-list">
							<?php for($i = 1; $i <= 10; $i++): ?>
							<?php if( isset($item['strategy'.$i]) ): ?>
							<li class="project-list__item"><?php echo e(Helpers::getLangString($item,'strategy'.$i)); ?></li>
							<?php endif; ?>
							<?php endfor; ?>
						</ul>
						<?php endif; ?>
					</div>
					<div class="col-lg-6 align-self-center">
						<?php if( isset($item->link) ): ?>
						<!-- <a href="<?php echo e($item->link); ?>" rel="nofollow" target="_blank" class="project__link d-none d-sm-table"><?php echo e($link['host'] .$path); ?></a> -->
						<?php endif; ?>
						<div class="project-screen d-none d-sm-block">
							<img src="/img/monitor.png" alt="screen" class="project-screen__bg">
							<img src="/<?php echo e($item->image); ?>" alt="screnn" class="project-screen__img" loading="lazy">
						</div>
					</div>
				</div>
				<?php if( isset( $item->result_title1 ) && isset( $item->result_text1 ) ): ?>
				<h5 class="project-text__ttl"><?php echo e(trans('main.result')); ?></h5>
				<div class="row">
					<div class="col-lg-3 col-6">
						<div class="project-result">
							<span class="project-result__numb"><?php echo e(Helpers::getLangString($item,'result_title1')); ?></span>
							<p class="project-result__txt"><?php echo e(Helpers::getLangString($item,'result_text1')); ?></p>
						</div>
					</div>
					<?php if( isset( $item->result_title2 ) && isset( $item->result_text2 ) ): ?>
					<div class="col-lg-3 col-6">
						<div class="project-result">
							<span class="project-result__numb"><?php echo e(Helpers::getLangString($item,'result_title2')); ?></span>
							<p class="project-result__txt"><?php echo e(Helpers::getLangString($item,'result_text2')); ?></p>
						</div>
					</div>
					<?php endif; ?>
					<?php if( isset( $item->result_title3 ) && isset( $item->result_text3 ) ): ?>
					<div class="col-lg-3 col-6">
						<div class="project-result">
							<span class="project-result__numb"><?php echo e(Helpers::getLangString($item,'result_title3')); ?></span>
							<p class="project-result__txt"><?php echo e(Helpers::getLangString($item,'result_text3')); ?></p>
						</div>
					</div>
					<?php endif; ?>
					<?php if( isset( $item->result_title4 ) && isset( $item->result_text4 ) ): ?>
					<div class="col-lg-3 col-6">
						<div class="project-result">
							<span class="project-result__numb"><?php echo e(Helpers::getLangString($item,'result_title4')); ?></span>
							<p class="project-result__txt"><?php echo e(Helpers::getLangString($item,'result_text4')); ?></p>
						</div>
					</div>
					<?php endif; ?>
				</div>
				<?php endif; ?>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</section>

<?php echo $__env->make('templates.example-form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.about', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.clients', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.map', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('templates.foot', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>