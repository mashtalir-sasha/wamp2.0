<section class="clients">
	<div class="container">
		<div class="row">
			<div class="col">
				<h3 class="clients__ttl"><?php echo trans('main.clients_ttl'); ?></h3>
				<div class="clients-slider">
				<?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div>
						<div>
							<div class="client">
								<div class="client-wrap">
									<img src="/<?php echo e($item->image); ?>" alt="client" class="client-wrap__img">
								</div>
								<p class="client__txt"><?php echo Helpers::getLangString($item,'name'); ?></p>
							</div>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
	</div>
</section>