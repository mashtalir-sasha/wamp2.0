<section id="contacts" class="contacts">
	<div class="contacts-block">
		<div class="contacts__ttl"><?php echo e(trans('main.contacts_ttl')); ?></div>
		<p class="contacts__addr"><?php echo Helpers::getLangString($contacts, 'addr'); ?></p>
		<a href="mailto:<?php echo e($contacts->email); ?>" class="contacts__eml"><?php echo e($contacts->email); ?></a>
		<a href="tel:+38<?php echo e(preg_replace('~[^0-9]~','',$contacts['phone'])); ?>" class="contacts__phone"><?php echo e($contacts->phone); ?></a>
		<span class="contacts__note">Viber/WhatsApp</span>
		<div class="contacts-soc">
			<?php if( isset($contacts->facebook) ): ?>
			<a href="<?php echo e($contacts->facebook); ?>" target="_blank" class="contacts-soc__link fb"></a>
			<?php endif; ?>
			<?php if( isset($contacts->linkedin) ): ?>
			<a href="<?php echo e($contacts->linkedin); ?>" target="_blank" class="contacts-soc__link linked"></a>
			<?php endif; ?>
			<?php if( isset($contacts->youtube) ): ?>
			<a href="<?php echo e($contacts->youtube); ?>" target="_blank" class="contacts-soc__link youtube"></a>
			<?php endif; ?>
		</div>
	</div>
	<div id="contacts_map">
		<?php echo $contacts->map; ?>

	</div>
</section>

<footer class="foot">
	<div class="container">
		<div class="row">
			<div class="col-md-4 order-2 order-md-1">
				<a href="https://www.google.com/partners/agency?id=1871712672" rel="nofollow" class="foot-link" target="_blank"><img src="https://wamp.com.ua/public/images/partners.png" alt="Google Partners - WAMP"></a>
				<a href="https://www.facebook.com/wamp.com.ua/" rel="nofollow" class="foot-link" target="_blank"><img src="https://wamp.com.ua/public/images/facebook-marketing-partner.png" alt="Facebook Partners - WAMP"></a>
			</div>
			<div class="col-md-4 order-1 order-md-2">
				<div class="foot-logo">
					<span class="foot-logo__note">web | advertising | marketing</span>
					<img src="/img/logo.svg" alt="logo" class="foot-logo__img">
				</div>
				<script type="text/javascript" src="https://widget.clutch.co/static/js/widget.js"></script>
				<div class="clutch-widget" data-url="https://widget.clutch.co" data-widget-type="2" data-height="50" data-darkbg="1" data-clutchcompany-id="762173" style="display:block;margin:40px 70px"></div>
				<a id="href2" rel="nofollow" target="_blank" href="http://www.2findlocal.com/b/13988869"></a>
				<!-- TrustBox widget - Micro Review Count -->
				<div class="trustpilot-widget" data-locale="en-US" data-template-id="5419b6a8b0d04a076446a9ad" data-businessunit-id="60e406df4f5f3b0001199ef5" data-style-height="24px" data-style-width="100%" data-theme="dark">
					<a href="https://www.trustpilot.com/review/wamp.com.ua" rel="nofollow" target="_blank" rel="noopener">Trustpilot</a>
				</div>
			</div>
			<div class="col-md-4 order-3">
				<a href="#callback" class="foot__btn fancybox"><?php echo e(trans('main.callback')); ?></a>
				<a href="tel:+38<?php echo e(preg_replace('~[^0-9]~','',$contacts['phone'])); ?>" class="foot__phone"><?php echo e($contacts->phone); ?></a>
				<a href="#" class="foot__conf"><?php echo e(trans('main.privacy')); ?></a>
			</div>
		</div>
	</div>
</footer>