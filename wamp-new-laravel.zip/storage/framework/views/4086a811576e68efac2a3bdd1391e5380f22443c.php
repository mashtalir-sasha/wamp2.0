<section class="map-con d-xl-block d-none">
	<div class="map-in">
	<?php $__currentLoopData = $maps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="markr" style="top: <?php echo e($item->position_top); ?>; <?php if(isset($item->position_left)): ?>left: <?php echo e($item->position_left); ?>;<?php endif; ?> <?php if(isset($item->position_right)): ?>right: <?php echo e($item->position_right); ?>;<?php endif; ?>">
			<a href="#" class="in-mark <?php if($loop->iteration == 1): ?> actm <?php endif; ?>">
				<span class="mark-name"><?php echo e(Helpers::getLangString($item,'place')); ?></span>
				<span class="mrkr-hover">
					<span class="intx">
						<?php echo Helpers::getLangString($item,'title'); ?>

						<span class="alink"><?php echo Helpers::getLangString($item,'text'); ?></span>
					</span>
				</span>
			</a>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</section>